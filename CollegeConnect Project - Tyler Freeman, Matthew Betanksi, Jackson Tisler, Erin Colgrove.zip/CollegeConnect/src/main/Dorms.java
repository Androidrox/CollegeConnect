package main;

public enum Dorms {
	Bridgeway,Cooper,Dobson,McGregor,Melcher,Morrow,Pickard,Porter,Rountree,Southwest,Wilgus
}
