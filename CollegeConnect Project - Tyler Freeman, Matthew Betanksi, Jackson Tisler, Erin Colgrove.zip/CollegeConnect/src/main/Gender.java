package main;

public enum Gender {
	Male,Female,Other
}
